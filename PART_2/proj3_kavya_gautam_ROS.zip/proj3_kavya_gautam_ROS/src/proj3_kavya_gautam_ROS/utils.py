import rospy
import tf
import math
import pygame
from proj3_kavya_gautam_ROS import constants

def pygame_obs(WINDOW):
    pygame.draw.circle(WINDOW, constants.BLUE, (200, 800), 100 )
    pygame.draw.polygon(WINDOW, constants.BLUE, ((25, 425), (175 , 425), (175 , 575 ), (25, 575 )))
    pygame.draw.polygon(WINDOW, constants.BLUE, ((375, 425), (625 , 425), (625 , 575 ), (375, 575 )))
    pygame.draw.circle(WINDOW, constants.BLUE, (200, 200), 100 )
    pygame.draw.polygon(WINDOW, constants.BLUE, ((725, 700), (875 , 700), (875 , 900 ), (725, 900 )))

def pygame_obs_th(WINDOW, clearance):
    pygame.draw.circle(WINDOW, constants.RED, (200, 800), 100 + clearance)
    pygame.draw.polygon(WINDOW, constants.RED, ((25 - clearance, 425 - clearance), (175 + clearance, 425 - clearance), (175 + clearance, 575 + clearance), (25 - clearance, 575 + clearance)))
    pygame.draw.polygon(WINDOW, constants.RED, ((375 - clearance, 425 - clearance), (625 + clearance, 425 - clearance), (625 + clearance, 575 + clearance), (375 - clearance, 575 + clearance)))
    pygame.draw.circle(WINDOW, constants.RED, (200, 200), 100 + clearance)
    pygame.draw.polygon(WINDOW, constants.RED, ((725 - clearance, 700 - clearance), (875 + clearance, 700 - clearance), (875 + clearance, 900 + clearance), (725 - clearance, 900 + clearance)))   

def half_plane(x, y, clearance):
    if (x < 0) or (x > 1000) or (y < 0) or (y > 1000): 
        return True
    elif (x-200)**2 + (y-800)**2 - (100+clearance)**2 <= 0:   
        return True
    elif x >= 25-clearance and x <= 175+clearance and y >= 425-clearance and y <= 575+clearance: 
        return True
    elif x >= 375-clearance and x <= 625+clearance and y >= 425-clearance and y <= 575+clearance:      
        return True
    elif (x-200)**2 + (y-200)**2 - (100+clearance)**2 <= 0:                
        return True
    elif x >= 725-clearance and x <= 875+clearance and y >= 200-clearance and y <= 400+clearance:      
        return True
    else:
        return False 

def calc_ang_to_goal(start_x, start_y, goal_x, goal_y):
    return math.atan2(goal_y - start_y, goal_x - start_x)

def compute_distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def compute_distance_astar(x1, y1, x2, y2):
    return (x2 - x1)**2 + (y2 - y1)**2

def compute_distance_region(dis, ang):
    return ((abs(dis)*ang*math.pi)/(180*1.20))

def avoid_obstacle(velocity, order):
    angular_velocity = order["angular_velocity"]
    velocity.linear.x = -0.10
    velocity.linear.y = 0
    velocity.angular.z = angular_velocity
    return velocity

def additional_check(msg, pub, rate, epoch):
    for i in range(epoch):
        rospy.loginfo("Giving backward jerk")
        msg.linear.x = -0.5
        msg.linear.y = 0
        msg.angular.z = -0.4
        pub.publish(msg)
        rate.sleep()

def wait_for_transform(pf, cf, time, duration):
    try:
        tf.TransformListener().waitForTransform(pf, cf, time, duration)
    except (tf.Exception, tf.ConnectivityException, tf.LookupException):
        rospy.loginfo("Cannot find transform between {p} and {c}".format(p=pf, c=cf))
        rospy.signal_shutdown("tf Exception")

def differential_calc(x, y, D, r, L, dt, theta, vel_left, vel_right):
    dx = 0.5*r * (vel_left + vel_right) * math.cos(theta) * dt
    x += dx        
    dy = 0.5*r * (vel_left + vel_right) * math.sin(theta) * dt        
    y += dy
    theta+= (r / L) * (vel_left + vel_right) * dt        
    D = D + (dx**2 + dy**2)**0.5
    return x, y, theta, D

def differential_vars():
    t = 0
    x = 0
    y = 0
    r = constants.r  
    L = constants.L   
    dt = constants.dt
    D = constants.D
    return t, x, y, r, L, dt, D

def linear_velocity_calc(r, rpm):
    return (2*math.pi*r*rpm)/60 